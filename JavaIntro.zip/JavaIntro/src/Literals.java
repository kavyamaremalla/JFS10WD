public class Literals {

    public static void main(String[] args) {

        //integer literals
        int decVal = 26;

        int octVal = 045;

        int hexaVal = 0x1a;

        int hexVal = 0b11010;


        System.out.println("Hello! " + '%' + "Welcome to course");

        String name = "john";

        boolean isEven = true;

        System.out.println(isEven);



    }
}
