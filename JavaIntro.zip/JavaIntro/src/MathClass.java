public class MathClass {

    public static void main(String[] args) {

        System.out.println("Max value is " + Math.max(18, 93));
        System.out.println("Min value is " + Math.min(Math.min(12, 22), 53));

        System.out.println("Square root " + Math.sqrt(61));
        System.out.println("Absolute value " + Math.abs(-78.95));

        System.out.println((int) (Math.random() * 102 + 89));



    }
}
